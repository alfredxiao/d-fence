(ns fencee.main
  (:require [clojure.string :as s]
    [ring.adapter.jetty :refer [run-jetty]]
            [cheshire.core :as cs]
            [ring.middleware
             [json :as rj]
             [params :as rp]
             [keyword-params :as rkp]]
            [compojure.core :refer [defroutes routes ANY PUT POST GET OPTIONS]]))

(def app-handler
  (routes
    (GET "/public" [] {:status 200
                       :headers {"Content-Type" "application/json"}
                       :body (cs/generate-string {:message "This is public information"})})

    (POST "/secret" [] {:status 200
                        :headers {"Content-Type" "application/json"}
                     :body {:message "This is PRIVATE!!!"}})

    (POST "/add" [] {:status 201
                     :body "something created"})

    (POST "/update/:id" [id] {:status 201
                              :headers {"Content-Type" "application/json"}
                              :body (cs/generate-string {:message "Updated"})})

          ;/facts/member-attributes/99/staff-flag
    (GET "/facts/member-attributes/:id/staff-flag" [id] {:status  200
                                       :headers {"Content-Type" "application/json"}
                                       :body    (if (> 100 (Integer/parseInt id))
                                                  "TRUE"
                                                  "FALSE")

                                                     #_(cs/generate-string {:entity-type "member-details"
                                                                     :id          id
                                                                     :staff-flag  (if (> 100 (Integer/parseInt id))
                                                                                    "TRUE"
                                                                                    "FALSE")})

                                                     })
  ))

(defonce server (atom nil))

(defn stop-jetty []
  (when @server
    (prn "Stopping dfence server...")
    (.stop @server)
    (reset! server nil)
    (prn "dfence server stopped.")))

(defn start-jetty []
  (prn "Starting API Backend server ...")
  (reset! server (run-jetty
                    (-> app-handler
                        rkp/wrap-keyword-params
                        rj/wrap-json-params
                        rp/wrap-params)
                    {:join? false
                     :ssl?  false
                     :host  "localhost"
                     :port  9090}))
  (prn "API Backend server started."))

(defn- -main [& args]
  (start-jetty))