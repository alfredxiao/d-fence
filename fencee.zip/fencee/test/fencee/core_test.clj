(ns fencee.core-test
  (:require [clojure.test :refer :all]
            [fencee.main :refer :all]))

(deftest a-test
  (testing "FIXME, I fail."
    (is (= 0 1))))
